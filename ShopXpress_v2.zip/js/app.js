// ============================================================
// APP.JS — Utilities, Navigation, Toast, Modal helpers
// ============================================================

// ── Toast notifications ────────────────────────────────────
function toast(msg, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success:'✅', error:'❌', info:'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${icons[type]||'💬'}</span><span>${msg}</span>`;
  container.appendChild(el);
  el.onclick = () => el.remove();
  setTimeout(() => el.remove(), 4000);
}

// ── Modal helpers ─────────────────────────────────────────
function openModal(html) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'global-modal';
  overlay.innerHTML = `<div class="modal">${html}</div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if(e.target === overlay) closeModal(); });
}
function closeModal() {
  const m = document.getElementById('global-modal');
  if(m) m.remove();
}

// ── Confirm dialog ────────────────────────────────────────
function confirm(msg) {
  return new Promise(resolve => {
    openModal(`
      <div class="modal-header"><h3 class="modal-title">Confirm</h3><button class="modal-close" onclick="closeModal()">×</button></div>
      <p style="color:var(--muted);margin-bottom:1.5rem">${msg}</p>
      <div class="flex gap-2">
        <button class="btn btn-danger" id="confirm-yes">Yes, Proceed</button>
        <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
      </div>
    `);
    setTimeout(() => {
      document.getElementById('confirm-yes')?.addEventListener('click', () => { closeModal(); resolve(true); });
    }, 50);
  });
}

// ── Auth guard ────────────────────────────────────────────
function requireCustomerAuth() {
  const sess = Store.getSession();
  if (!sess || sess.role !== 'customer') {
    window.location.href = 'index.html';
    return null;
  }
  return sess;
}

function requireAdminAuth() {
  const sess = Store.getSession();
  if (!sess || sess.role !== 'admin') {
    window.location.href = 'admin-login.html';
    return null;
  }
  return sess;
}

// ── Render customer navbar ────────────────────────────────
function renderCustomerNav(activeLink = '') {
  const sess = Store.getSession();
  const cartCount = Store.getCart().length;
  const nav = document.getElementById('main-nav');
  if (!nav) return;
  nav.innerHTML = `
    <div class="brand">Shop<span>Xpress</span></div>
    <ul class="nav-links">
      <li><a href="home.html" class="${activeLink==='home'?'active':''}">🏠 Home</a></li>
      <li><a href="cart.html" class="${activeLink==='cart'?'active':''}">🛒 My Cart <span class="cart-badge">${cartCount||0}</span></a></li>
      <li><a href="orders.html" class="${activeLink==='orders'?'active':''}">📦 My Orders</a></li>
    </ul>
    <div class="nav-right">
      <span class="nav-user">👤 ${sess?.name || ''}</span>
      <a href="profile.html" class="btn btn-outline btn-sm">Profile</a>
      <button class="btn btn-outline btn-sm" onclick="logout()">Logout</button>
    </div>
  `;
}

function renderAdminNav(activeSection = '') {
  const nav = document.getElementById('main-nav');
  const sess = Store.getSession();
  if (!nav) return;
  nav.innerHTML = `
    <div class="brand">Shop<span>Xpress</span> <span style="font-size:.7rem;color:var(--muted);font-family:var(--font-body)">Admin</span></div>
    <div class="nav-right">
      <span class="nav-user">🛠️ ${sess?.name || 'Admin'}</span>
      <button class="btn btn-outline btn-sm" onclick="logout()">Logout</button>
    </div>
  `;
}

function logout() {
  const sess = Store.getSession();
  Store.clearSession();
  if (sess?.role === 'admin') {
    window.location.href = 'admin-login.html';
  } else {
    window.location.href = 'index.html';
  }
}

// ── Pagination helper ─────────────────────────────────────
function paginate(items, page, perPage = 10) {
  const total = Math.ceil(items.length / perPage);
  const slice = items.slice((page - 1) * perPage, page * perPage);
  return { items: slice, total, page };
}

function renderPagination(container, current, total, onPage) {
  container.innerHTML = '';
  if (total <= 1) return;
  const prev = document.createElement('button');
  prev.className = 'page-btn'; prev.textContent = '← Prev'; prev.disabled = current === 1;
  prev.onclick = () => onPage(current - 1);
  container.appendChild(prev);
  for (let i = 1; i <= total; i++) {
    const b = document.createElement('button');
    b.className = 'page-btn' + (i === current ? ' active' : '');
    b.textContent = i; b.onclick = () => onPage(i);
    container.appendChild(b);
  }
  const next = document.createElement('button');
  next.className = 'page-btn'; next.textContent = 'Next →'; next.disabled = current === total;
  next.onclick = () => onPage(current + 1);
  container.appendChild(next);
}

// ── Badge helper ──────────────────────────────────────────
function statusBadge(status) {
  const map = {
    'Confirmed':  'badge-confirmed',
    'Delivered':  'badge-delivered',
    'In Transit': 'badge-transit',
    'Cancelled':  'badge-cancelled',
    'Active':     'badge-active',
    'In Active':  'badge-inactive',
  };
  return `<span class="product-badge ${map[status]||''}">${status}</span>`;
}

// ── Format currency ───────────────────────────────────────
function rupee(n) { return '₹' + Number(n).toLocaleString('en-IN'); }

// ── Date format ───────────────────────────────────────────
function fmtDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
}
